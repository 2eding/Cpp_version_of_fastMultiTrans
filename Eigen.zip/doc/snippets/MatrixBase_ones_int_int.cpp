cout << MatrixXi::Ones(2,3) << endl;
